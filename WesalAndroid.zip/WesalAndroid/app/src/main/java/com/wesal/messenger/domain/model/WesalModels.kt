package com.wesal.messenger.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class SavedWesalAccount(
    val uid: String = "",
    val displayName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val publicId: String = "",
    val numericId: String = "",
    val photoUrl: String = "",
    val provider: String = "email",
    val lastUsedAt: Long = System.currentTimeMillis()
)

enum class PrivacyVisibility(val key: String) {
    EVERYONE("everyone"),
    CONTACTS("contacts"),
    NOBODY("nobody");

    companion object {
        fun fromKey(key: String?): PrivacyVisibility =
            entries.firstOrNull { it.key == key } ?: EVERYONE
    }
}

enum class StoryAudienceMode(val raw: String) {
    CONTACTS("CONTACTS"),
    CONTACTS_EXCEPT("CONTACTS_EXCEPT"),
    ONLY_WITH("ONLY_WITH"),
    ALL_CONTACTS("ALL_CONTACTS");

    companion object {
        fun fromRaw(raw: String?): StoryAudienceMode =
            entries.firstOrNull { it.raw == raw } ?: CONTACTS
    }
}

enum class GroupJoinMode(val raw: String) {
    OPEN("OPEN"),
    APPROVAL_REQUIRED("APPROVAL_REQUIRED"),
    CLOSED("CLOSED"),
    INVITE_ONLY("INVITE_ONLY");

    companion object {
        fun fromRaw(raw: String?): GroupJoinMode =
            entries.firstOrNull { it.raw == raw } ?: OPEN
    }
}

@Serializable
data class BusinessDaySlot(
    val openTime: String = "09:00",
    val closeTime: String = "17:00"
)

@Serializable
data class BusinessDayHours(
    val dayKey: String = "SAT", // SAT, SUN, MON, TUE, WED, THU, FRI
    val isClosed: Boolean = false,
    val isOpen24Hours: Boolean = false,
    val slots: List<BusinessDaySlot> = listOf(BusinessDaySlot())
)

@Serializable
data class BusinessHoursSchedule(
    val enabled: Boolean = false,
    val businessName: String = "",
    val timeZoneId: String = "Africa/Cairo",
    val days: List<BusinessDayHours> = listOf(
        BusinessDayHours("SAT"),
        BusinessDayHours("SUN"),
        BusinessDayHours("MON"),
        BusinessDayHours("TUE"),
        BusinessDayHours("WED"),
        BusinessDayHours("THU"),
        BusinessDayHours("FRI", isClosed = true)
    )
)

data class PrivacySettings(
    val lastSeenVisibility: PrivacyVisibility = PrivacyVisibility.EVERYONE,
    val onlineVisibility: PrivacyVisibility = PrivacyVisibility.EVERYONE,
    val profilePhotoVisibility: PrivacyVisibility = PrivacyVisibility.EVERYONE,
    val storiesVisibility: PrivacyVisibility = PrivacyVisibility.EVERYONE,
    val readReceiptsEnabled: Boolean = true,
    val hidePhoneNumber: Boolean = false,
    val hideBirthDate: Boolean = false,
    val recordProfileVisits: Boolean = true
)

data class WesalUser(
    val uid: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val isPhoneVerified: Boolean = false,
    val isVerified: Boolean = false,
    val verificationType: String = "BLUE", // BLUE, BLACK, GREEN
    val verificationExpiresAt: Long = 0L, // 0 = permanent
    val verifiedByUid: String = "",
    val verifiedAt: Long = 0L,
    val verificationNote: String = "",
    val displayName: String = "",
    val publicId: String = "",
    val numericId: String = "",
    val bio: String = "أستخدم تطبيق WESAL",
    val photoUrl: String = "",
    val coverUrl: String = "",
    val birthDate: String = "", // ISO YYYY-MM-DD (timezone-independent)
    val frameId: String = "",
    val frameExpiresAt: Long = 0L, // 0 = permanent
    val neonColor: String = "", // "", RED, GREEN, BLACK, BLUE
    val neonGlowIntensity: Float = 0.7f,
    val facebookUrl: String = "",
    val instagramUrl: String = "",
    val businessHours: BusinessHoursSchedule = BusinessHoursSchedule(),
    val locationGranted: Boolean = false,
    val locationFallbackStartedAt: Long = 0L,
    val profileCompleted: Boolean = false,
    val welcomeSent: Boolean = false,
    val hiddenFromSearch: Boolean = false,
    val hideFromSearchReason: String = "",
    val hiddenAt: Long = 0L,
    val hiddenByUid: String = "",
    val isBanned: Boolean = false,
    val banType: String = "", // TEMPORARY, PERMANENT
    val banReason: String = "",
    val banExpiresAt: Long = 0L,
    val warningsCount: Int = 0,
    val deletedAt: Long = 0L,
    val createdAt: Long = 0L,
    val lastSeen: Long = 0L,
    val lastHeartbeatAt: Long = 0L,
    val isOnline: Boolean = false,
    val activeSessionsCount: Int = 0,
    val lastDeviceName: String = "",
    val lastAppVersion: String = "",
    val lastActivityType: String = "", // CHAT, GROUP, CHANNEL, NONE
    val lastActivityChatId: String = "",
    val lastActivityParticipantsCount: Int = 0,
    val lastActivityAt: Long = 0L,
    val fcmToken: String = "",
    val publicKey: String = "",
    val privacySettings: PrivacySettings = PrivacySettings(),
    val blockedUsers: List<String> = emptyList()
)

enum class ContactRequestStatus(val raw: String) {
    PENDING("PENDING"),
    ACCEPTED("ACCEPTED"),
    REJECTED("REJECTED");

    companion object {
        fun fromRaw(raw: String?): ContactRequestStatus =
            entries.firstOrNull { it.raw == raw } ?: PENDING
    }
}

data class ContactRequest(
    val requestId: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val senderPublicId: String = "",
    val senderAvatarUrl: String = "",
    val senderVerified: Boolean = false,
    val receiverUid: String = "",
    val receiverName: String = "",
    val receiverPublicId: String = "",
    val receiverAvatarUrl: String = "",
    val receiverVerified: Boolean = false,
    val status: ContactRequestStatus = ContactRequestStatus.PENDING,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class ProfileVisitor(
    val visitorUid: String = "",
    val visitorName: String = "",
    val visitorPublicId: String = "",
    val visitorNumericId: String = "",
    val visitorAvatarUrl: String = "",
    val visitorVerified: Boolean = false,
    val visitorVerificationType: String = "BLUE",
    val visitedAt: Long = System.currentTimeMillis()
)

data class VerificationAuditLog(
    val logId: String = "",
    val operationId: String = "",
    val targetUid: String = "",
    val targetNumericId: String = "",
    val targetPublicId: String = "",
    val targetName: String = "",
    val action: String = "GRANTED", // GRANTED, REVOKED, EXPIRED, FRAME_GRANTED, NEON_UPDATED, HIDDEN, UNHIDDEN, etc.
    val verificationType: String = "BLUE",
    val durationLabel: String = "",
    val expiresAt: Long = 0L,
    val adminUid: String = "",
    val adminEmail: String = "",
    val note: String = "",
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class AdminReportRecord(
    val reportId: String = "",
    val reporterUid: String = "",
    val reporterName: String = "",
    val reportedUid: String = "",
    val reportedName: String = "",
    val targetType: String = "USER", // USER, MESSAGE, CHAT, CHANNEL, POST, STORY
    val targetChatId: String = "",
    val targetMessageId: String = "",
    val targetContentSnapshot: String = "",
    val reason: String = "",
    val status: String = "NEW", // NEW, IN_REVIEW, RESOLVED, REJECTED, CLOSED
    val adminNote: String = "",
    val resolutionAction: String = "",
    val reviewedByUid: String = "",
    val reviewedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

data class OfficialAnnouncement(
    val announcementId: String = "",
    val title: String = "WESAL Messenger",
    val body: String = "",
    val adminUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class SystemWelcomeConfig(
    val enabled: Boolean = true,
    val messageTemplate: String = DEFAULT_OFFICIAL_WELCOME_TEMPLATE,
    val previousVersions: List<String> = emptyList(),
    val updatedAt: Long = 0L,
    val updatedByUid: String = ""
) {
    companion object {
        const val DEFAULT_OFFICIAL_WELCOME_TEMPLATE =
            "مرحبًا بك يا [اسم المستخدم] 👋\n\n" +
                "أهلًا وسهلًا بك في WESAL Messenger ❤️\n\n" +
                "سعداء جدًا بانضمامك إلى عائلة وصال!\n\n" +
                "من هنا تبدأ رحلتك للتواصل مع أصدقائك ومشاركة لحظاتك بكل سهولة.\n\n" +
                "يمكنك إرسال الرسائل والصور والفيديوهات والتسجيلات الصوتية، وإجراء المكالمات الصوتية والمرئية، وإنشاء المجموعات والقنوات والتواصل مع الأشخاص الذين تعرفهم.\n\n" +
                "نحرص دائمًا على توفير تجربة سهلة وآمنة تحترم خصوصيتك.\n\n" +
                "نتمنى لك وقتًا ممتعًا وتجربة رائعة معنا ❤️\n\n" +
                "أهلًا بك بيننا.\n\n" +
                "فريق وصال | WESAL Team"
    }
}

data class AdminDashboardStats(
    val totalAccounts: Int = 0,
    val onlineNowCount: Int = 0,
    val offlineCount: Int = 0,
    val newTodayCount: Int = 0,
    val newTwoDaysCount: Int = 0,
    val newWeekCount: Int = 0,
    val newMonthCount: Int = 0,
    val activeTodayCount: Int = 0,
    val activeWeekCount: Int = 0,
    val activeMonthCount: Int = 0,
    val bannedCount: Int = 0,
    val deletedCount: Int = 0,
    val hiddenCount: Int = 0,
    val verifiedCount: Int = 0
)

enum class MessageType(val raw: String) {
    TEXT("TEXT"),
    IMAGE("IMAGE"),
    VIDEO("VIDEO"),
    VOICE("VOICE"),
    AUDIO("AUDIO"),
    DOCUMENT("DOCUMENT"),
    LOCATION("LOCATION"),
    SYSTEM("SYSTEM");

    companion object {
        fun fromRaw(raw: String?): MessageType =
            entries.firstOrNull { it.raw == raw } ?: TEXT
    }
}

enum class MessageStatus(val raw: String) {
    SENDING("SENDING"),
    SENT("SENT"),
    DELIVERED("DELIVERED"),
    READ("READ"),
    FAILED("FAILED");

    companion object {
        fun fromRaw(raw: String?): MessageStatus =
            entries.firstOrNull { it.raw == raw } ?: SENT
    }
}

data class WesalMessage(
    val messageId: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val type: MessageType = MessageType.TEXT,
    val ciphertext: String = "",
    val text: String = "",
    val isEncrypted: Boolean = false,
    val isViewOnce: Boolean = false,
    val viewedBy: List<String> = emptyList(),
    val mediaUrl: String = "",
    val mediaLocalPath: String = "",
    val mediaMimeType: String = "",
    val mediaFileName: String = "",
    val mediaSizeBytes: Long = 0L,
    val mediaDurationMs: Long = 0L,
    val waveformAmplitudes: List<Int> = emptyList(),
    val wrappedKeys: Map<String, String> = emptyMap(),
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationAddress: String = "",
    val replyToMessageId: String? = null,
    val replyToPreview: String? = null,
    val forwardedFromName: String? = null,
    val isEdited: Boolean = false,
    val isDeletedForEveryone: Boolean = false,
    val deletedForUsers: List<String> = emptyList(),
    val status: MessageStatus = MessageStatus.SENT,
    val uploadProgress: Float? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatPreview(
    val chatId: String = "",
    val isGroup: Boolean = false,
    val groupId: String? = null,
    val participantIds: List<String> = emptyList(),
    val peerUid: String = "",
    val title: String = "",
    val avatarUrl: String = "",
    val peerPublicKey: String = "",
    val peerOnline: Boolean = false,
    val peerLastSeen: Long = 0L,
    val peerVerified: Boolean = false,
    val peerVerificationType: String = "BLUE",
    val peerFrameId: String = "",
    val peerFrameExpiresAt: Long = 0L,
    val officialWallpaperUrl: String = "",
    val lastMessagePreview: String = "",
    val lastMessageTime: Long = 0L,
    val lastMessageSenderId: String = "",
    val lastMessageStatus: MessageStatus = MessageStatus.SENT,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val isSupportChat: Boolean = false,
    val isOfficialWesalChat: Boolean = false,
    val deletedForUsers: List<String> = emptyList(),
    val typingUsers: List<String> = emptyList()
)

data class GroupInfo(
    val groupId: String = "",
    val chatId: String = "",
    val name: String = "",
    val description: String = "",
    val avatarUrl: String = "",
    val creatorId: String = "",
    val adminIds: List<String> = emptyList(),
    val memberIds: List<String> = emptyList(),
    val joinMode: GroupJoinMode = GroupJoinMode.OPEN,
    val inviteCode: String = "",
    val inviteRevokedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

data class GroupJoinRequest(
    val requestId: String = "",
    val groupId: String = "",
    val requesterUid: String = "",
    val requesterName: String = "",
    val requesterNumericId: String = "",
    val requesterAvatarUrl: String = "",
    val status: String = "PENDING",
    val createdAt: Long = System.currentTimeMillis()
)

enum class ChannelRole {
    OWNER,
    MODERATOR,
    SUBSCRIBER,
    NONE
}

data class WesalChannel(
    val channelId: String = "",
    val title: String = "",
    val description: String = "",
    val avatarUrl: String = "",
    val officialWallpaperUrl: String = "",
    val isPublic: Boolean = true,
    val isOfficialTeamChannel: Boolean = false,
    val isSuspended: Boolean = false,
    val inviteCode: String = "",
    val ownerUid: String = "",
    val moderatorIds: List<String> = emptyList(),
    val subscriberIds: List<String> = emptyList(),
    val subscribersCount: Int = 0,
    val isVerified: Boolean = false,
    val verificationType: String = "BLUE",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun roleFor(uid: String): ChannelRole = when {
        uid.isBlank() -> ChannelRole.NONE
        ownerUid == uid -> ChannelRole.OWNER
        moderatorIds.contains(uid) -> ChannelRole.MODERATOR
        subscriberIds.contains(uid) -> ChannelRole.SUBSCRIBER
        else -> ChannelRole.NONE
    }
}

enum class ChannelPostType(val raw: String) {
    TEXT("TEXT"),
    IMAGE("IMAGE"),
    VIDEO("VIDEO"),
    AUDIO("AUDIO"),
    DOCUMENT("DOCUMENT");

    companion object {
        fun fromRaw(raw: String?): ChannelPostType =
            entries.firstOrNull { it.raw == raw } ?: TEXT
    }
}

data class ChannelPost(
    val postId: String = "",
    val channelId: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val authorAvatarUrl: String = "",
    val authorVerified: Boolean = false,
    val type: ChannelPostType = ChannelPostType.TEXT,
    val text: String = "",
    val mediaUrl: String = "",
    val mediaMimeType: String = "",
    val mediaFileName: String = "",
    val mediaSizeBytes: Long = 0L,
    val mediaDurationMs: Long = 0L,
    val reactionCounts: Map<String, Int> = emptyMap(),
    val userReactions: Map<String, String> = emptyMap(),
    val isPinned: Boolean = false,
    val commentsCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

data class ChannelComment(
    val commentId: String = "",
    val postId: String = "",
    val channelId: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val authorAvatarUrl: String = "",
    val authorVerified: Boolean = false,
    val text: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class ChannelJoinRequest(
    val requestId: String = "",
    val channelId: String = "",
    val requesterUid: String = "",
    val requesterName: String = "",
    val requesterPublicId: String = "",
    val requesterAvatarUrl: String = "",
    val status: String = "PENDING",
    val createdAt: Long = System.currentTimeMillis()
)

enum class StoryType(val raw: String) {
    TEXT("TEXT"),
    IMAGE("IMAGE"),
    VIDEO("VIDEO"),
    AUDIO("AUDIO");

    companion object {
        fun fromRaw(raw: String?): StoryType =
            entries.firstOrNull { it.raw == raw } ?: TEXT
    }
}

data class StoryItem(
    val storyId: String = "",
    val ownerUid: String = "",
    val ownerName: String = "",
    val ownerAvatarUrl: String = "",
    val ownerVerified: Boolean = false,
    val type: StoryType = StoryType.TEXT,
    val textContent: String = "",
    val backgroundColorHex: Long = 0xFF064E3B,
    val mediaUrl: String = "",
    val caption: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 24 * 60 * 60 * 1000L,
    val visibility: PrivacyVisibility = PrivacyVisibility.CONTACTS,
    val audienceMode: StoryAudienceMode = StoryAudienceMode.CONTACTS,
    val allowedViewerIds: List<String> = emptyList(),
    val excludedViewerIds: List<String> = emptyList(),
    val viewerIds: List<String> = emptyList()
)

data class StoryViewer(
    val uid: String = "",
    val displayName: String = "",
    val photoUrl: String = "",
    val viewedAt: Long = 0L
)

enum class CallStatus(val raw: String) {
    CONNECTING("CONNECTING"),
    RINGING("RINGING"),
    ACTIVE("ACTIVE"),
    ENDED("ENDED"),
    MISSED("MISSED"),
    REJECTED("REJECTED");

    companion object {
        fun fromRaw(raw: String?): CallStatus =
            entries.firstOrNull { it.raw == raw } ?: ENDED
    }
}

data class CallRecord(
    val callId: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callerAvatarUrl: String = "",
    val callerVerified: Boolean = false,
    val calleeId: String = "",
    val calleeName: String = "",
    val calleeAvatarUrl: String = "",
    val calleeVerified: Boolean = false,
    val isVideo: Boolean = false,
    val status: CallStatus = CallStatus.CONNECTING,
    val calleeRingingAck: Boolean = false,
    val ringingAt: Long = 0L,
    val offerSdp: String = "",
    val answerSdp: String = "",
    val deletedForUsers: List<String> = emptyList(),
    val startedAt: Long = System.currentTimeMillis(),
    val endedAt: Long = 0L,
    val durationSeconds: Long = 0L
)

data class DeviceSession(
    val sessionId: String = "",
    val deviceName: String = "",
    val osVersion: String = "",
    val appVersion: String = "",
    val lastActiveAt: Long = System.currentTimeMillis(),
    val isCurrent: Boolean = false
)

data class CountryCode(
    val nameAr: String,
    val nameEn: String,
    val iso: String,
    val dialCode: String,
    val flagEmoji: String
)
