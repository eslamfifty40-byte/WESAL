package com.wesal.messenger.chat

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.rememberPermissionState
import com.google.android.gms.location.LocationServices
import com.wesal.messenger.calls.CallActivity
import com.wesal.messenger.core.theme.WesalColors
import com.wesal.messenger.core.util.DateTimeUtils
import com.wesal.messenger.core.util.LocalWesalStrings
import com.wesal.messenger.domain.model.MessageType
import com.wesal.messenger.domain.model.WesalMessage
import com.wesal.messenger.media.CameraCaptureScreen
import com.wesal.messenger.media.FullscreenImageViewer
import com.wesal.messenger.media.VideoPlayerBox
import com.wesal.messenger.presentation.components.MessageStatusTick
import com.wesal.messenger.presentation.components.WesalAvatar
import com.wesal.messenger.presentation.components.WesalEmojiKeyboard
import com.wesal.messenger.presentation.components.WesalEmojiUtils
import com.wesal.messenger.presentation.components.WesalNameWithBadge
import com.wesal.messenger.voice.VoicePlaybackState
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun ChatDetailScreen(
    onBack: () -> Unit,
    onOpenGroupInfo: (String) -> Unit,
    onOpenUserProfile: (String) -> Unit = {},
    viewModel: ChatDetailViewModel = hiltViewModel()
) {
    val palette = WesalColors.current
    val strings = LocalWesalStrings.current
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScope()
    val composerFocusRequester = remember { FocusRequester() }

    val chat by viewModel.chatPreview.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val replyingTo by viewModel.replyingTo.collectAsStateWithLifecycle()
    val editingMessage by viewModel.editingMessage.collectAsStateWithLifecycle()
    val pendingUploads by viewModel.pendingUploads.collectAsStateWithLifecycle()
    val decryptedFiles by viewModel.decryptedFiles.collectAsStateWithLifecycle()
    val recordingState by viewModel.recordingState.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val toastMsg by viewModel.toastMessage.collectAsStateWithLifecycle()
    val allChats by viewModel.allChatsForForward.collectAsStateWithLifecycle()
    val recentEmojis by viewModel.recentEmojis.collectAsStateWithLifecycle()
    val quickReplies by viewModel.quickReplies.collectAsStateWithLifecycle()

    var inputValue by remember { mutableStateOf(TextFieldValue("")) }
    var showSearchBar by remember { mutableStateOf(false) }
    var showQuickRepliesBar by remember { mutableStateOf(false) }
    var showCamera by remember { mutableStateOf(false) }
    var showAttachSheet by remember { mutableStateOf(false) }
    var showEmojiKeyboard by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var fullscreenImageFile by remember { mutableStateOf<File?>(null) }
    var playingVideoFile by remember { mutableStateOf<File?>(null) }
    var selectedMessageForActions by remember { mutableStateOf<WesalMessage?>(null) }
    var forwardingMessage by remember { mutableStateOf<WesalMessage?>(null) }

    val listState = rememberLazyListState()
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)
    val locationPermissions = rememberMultiplePermissionsState(
        listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    )

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.sendPickedMedia(uri, isVideo = false)
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.sendPickedMedia(uri, isVideo = true)
    }

    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.sendAudioFile(uri)
    }

    val documentPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.sendDocument(uri)
    }

    BackHandler(enabled = showEmojiKeyboard || showCamera || fullscreenImageFile != null || playingVideoFile != null) {
        when {
            fullscreenImageFile != null -> fullscreenImageFile = null
            playingVideoFile != null -> playingVideoFile = null
            showCamera -> showCamera = false
            showEmojiKeyboard -> showEmojiKeyboard = false
        }
    }

    LaunchedEffect(editingMessage?.messageId) {
        editingMessage?.let {
            inputValue = TextFieldValue(it.text, TextRange(it.text.length))
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
            viewModel.markRead()
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toastMsg) {
        toastMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    if (showCamera) {
        CameraCaptureScreen(
            onMediaConfirmed = { uri, isVideo, caption ->
                viewModel.sendPickedMedia(uri, isVideo, caption)
                showCamera = false
            },
            onClose = { showCamera = false }
        )
        return
    }

    fullscreenImageFile?.let { file ->
        FullscreenImageViewer(
            imageModel = file,
            onClose = { fullscreenImageFile = null }
        )
        return
    }

    playingVideoFile?.let { file ->
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            VideoPlayerBox(uri = Uri.fromFile(file), modifier = Modifier.fillMaxSize())
            IconButton(
                onClick = { playingVideoFile = null },
                modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
            ) {
                Icon(Icons.Default.Close, contentDescription = strings.close, tint = Color.White)
            }
        }
        return
    }

    Scaffold(
        containerColor = palette.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = palette.surface),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back, tint = palette.textPrimary)
                    }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.clickable {
                            val curChat = chat
                            if (curChat?.isGroup == true && !curChat.groupId.isNullOrBlank()) {
                                onOpenGroupInfo(curChat.groupId)
                            } else if (curChat != null && curChat.peerUid.isNotBlank()) {
                                onOpenUserProfile(curChat.peerUid)
                            }
                        }
                    ) {
                        WesalAvatar(
                            imageUrl = chat?.avatarUrl.orEmpty(),
                            name = chat?.title ?: strings.appShortName,
                            size = 38.dp,
                            isOnline = chat?.isGroup == false && chat?.peerOnline == true
                        )
                        Column {
                            WesalNameWithBadge(
                                name = chat?.title ?: if (strings.isEnglish) "Chat" else "محادثة",
                                isVerified = chat?.isGroup == false && chat?.peerVerified == true,
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                            val subtitle = when {
                                chat?.typingUsers?.isNotEmpty() == true -> strings.typingNow
                                chat?.isGroup == true -> if (strings.isEnglish) "${chat?.participantIds?.size ?: 0} members" else "${chat?.participantIds?.size ?: 0} عضو"
                                chat?.peerOnline == true -> strings.onlineNow
                                (chat?.peerLastSeen ?: 0L) > 0L ->
                                    if (strings.isEnglish) "Last seen ${DateTimeUtils.formatChatListTime(chat!!.peerLastSeen)}"
                                    else "آخر ظهور ${DateTimeUtils.formatChatListTime(chat!!.peerLastSeen)}"
                                else -> if (strings.isEnglish) "WESAL • Secure HTTPS" else "WESAL • اتصال آمن HTTPS"
                            }
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (chat?.typingUsers?.isNotEmpty() == true || chat?.peerOnline == true) {
                                    palette.emerald
                                } else {
                                    palette.textSecondary
                                }
                            )
                        }
                    }
                },
                actions = {
                    if (chat?.isGroup == false) {
                        IconButton(onClick = {
                            scope.launch {
                                val peer = viewModel.getPeerUser() ?: return@launch
                                context.startActivity(
                                    CallActivity.createOutgoingIntent(context, peer, isVideo = true)
                                )
                            }
                        }) {
                            Icon(Icons.Default.Videocam, contentDescription = null, tint = palette.textPrimary)
                        }
                        IconButton(onClick = {
                            scope.launch {
                                val peer = viewModel.getPeerUser() ?: return@launch
                                context.startActivity(
                                    CallActivity.createOutgoingIntent(context, peer, isVideo = false)
                                )
                            }
                        }) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = palette.textPrimary)
                        }
                    }
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = strings.more, tint = palette.textPrimary)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            containerColor = palette.surface
                        ) {
                            if (chat?.isGroup == false && !chat?.peerUid.isNullOrBlank()) {
                                DropdownMenuItem(
                                    text = { Text(if (strings.isEnglish) "View Profile" else "عرض الملف الشخصي", color = palette.textPrimary) },
                                    onClick = {
                                        onOpenUserProfile(chat!!.peerUid)
                                        showMenu = false
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text(if (strings.isEnglish) "Search in Chat" else "بحث في المحادثة", color = palette.textPrimary) },
                                onClick = { showSearchBar = !showSearchBar; showMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text(if (strings.isEnglish) "Quick Replies" else "الردود السريعة", color = palette.textPrimary) },
                                onClick = { showQuickRepliesBar = !showQuickRepliesBar; showMenu = false }
                            )
                            if (chat?.isGroup == false && !chat?.peerUid.isNullOrBlank()) {
                                DropdownMenuItem(
                                    text = { Text(if (strings.isEnglish) "Block User" else "حظر المستخدم", color = palette.error) },
                                    onClick = {
                                        viewModel.blockPeer(chat!!.peerUid)
                                        showMenu = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (strings.isEnglish) "Report Abuse" else "إبلاغ عن إساءة", color = palette.warning) },
                                    onClick = {
                                        viewModel.reportPeer(chat!!.peerUid, "Reported from chat")
                                        showMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
        ) {
            if (showSearchBar) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = viewModel::setSearchQuery,
                    placeholder = {
                        Text(
                            text = if (strings.isEnglish) "Search messages..." else "ابحث داخل الرسائل...",
                            color = palette.textMuted
                        )
                    },
                    trailingIcon = {
                        IconButton(onClick = { viewModel.setSearchQuery(""); showSearchBar = false }) {
                            Icon(Icons.Default.Close, contentDescription = strings.close, tint = palette.textSecondary)
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary,
                        cursorColor = palette.turquoise,
                        focusedBorderColor = palette.turquoise,
                        unfocusedBorderColor = palette.border,
                        focusedPlaceholderColor = palette.textMuted,
                        unfocusedPlaceholderColor = palette.textMuted,
                        focusedContainerColor = palette.surfaceElevated,
                        unfocusedContainerColor = palette.surfaceElevated
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(messages, key = { it.messageId }) { msg ->
                    val isMine = msg.senderId == viewModel.myUid
                    MessageBubble(
                        message = msg,
                        isMine = isMine,
                        isGroup = chat?.isGroup == true,
                        decryptedFile = decryptedFiles[msg.messageId],
                        playbackState = playbackState,
                        onRequestMedia = { viewModel.resolveMediaFile(msg) },
                        onOpenImage = { viewModel.resolveMediaFile(msg) { fullscreenImageFile = it } },
                        onPlayVideo = { viewModel.resolveMediaFile(msg) { playingVideoFile = it } },
                        onToggleVoice = { viewModel.toggleVoicePlayback(msg) },
                        onSeekAudio = { posMs -> viewModel.seekAudio(posMs) },
                        onSetVolume = { vol -> viewModel.setAudioVolume(vol) },
                        onSaveAudio = { viewModel.saveAudioToDownloads(msg, strings.isEnglish) },
                        onOpenDocument = {
                            viewModel.resolveMediaFile(msg) { file ->
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uri, msg.mediaMimeType.ifBlank { "*/*" })
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                runCatching { context.startActivity(intent) }
                            }
                        },
                        onOpenLocation = {
                            val lat = msg.latitude ?: 0.0
                            val lng = msg.longitude ?: 0.0
                            val geo = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(msg.locationAddress)})")
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, geo)) }
                        },
                        onLongClick = { selectedMessageForActions = msg }
                    )
                }

                items(pendingUploads, key = { it.id }) { upload ->
                    Surface(
                        color = palette.bubbleOutgoing.copy(alpha = 0.8f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(0.78f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (strings.isEnglish) "Sending: ${upload.fileName}" else "جاري إرسال: ${upload.fileName}",
                                    color = palette.textPrimary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (upload.error != null) {
                                    IconButton(onClick = { viewModel.dismissUpload(upload.id) }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = strings.close, tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            if (upload.error != null) {
                                Text(upload.error, color = palette.error, style = MaterialTheme.typography.labelSmall)
                                TextButton(onClick = { viewModel.retryUpload(upload) }) {
                                    Text(strings.retry, color = palette.turquoise)
                                }
                            } else {
                                LinearProgressIndicator(progress = { upload.progress }, color = palette.turquoise)
                            }
                        }
                    }
                }
            }

            // Reply / Edit Banner
            val bannerTitle = when {
                editingMessage != null -> if (strings.isEnglish) "Editing message" else "تعديل الرسالة"
                replyingTo != null -> if (strings.isEnglish) "Reply to ${replyingTo!!.senderName}" else "رد على ${replyingTo!!.senderName}"
                else -> null
            }
            if (bannerTitle != null) {
                Surface(color = palette.surfaceElevated, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(bannerTitle, color = palette.turquoise, style = MaterialTheme.typography.labelMedium)
                            Text(
                                text = (editingMessage?.text ?: replyingTo?.text).orEmpty(),
                                color = palette.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        IconButton(onClick = {
                            viewModel.setReplyingTo(null)
                            viewModel.setEditingMessage(null)
                        }) {
                            Icon(Icons.Default.Close, contentDescription = strings.cancel, tint = palette.textSecondary)
                        }
                    }
                }
            }

            // Quick Replies Strip (1-tap send)
            if (showQuickRepliesBar && quickReplies.isNotEmpty() && !recordingState.isRecording) {
                Surface(color = palette.surfaceElevated, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        quickReplies.forEach { preset ->
                            Surface(
                                color = palette.surface,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, palette.turquoise.copy(alpha = 0.45f)),
                                modifier = Modifier.clickable {
                                    viewModel.sendOrEditText(preset)
                                    showQuickRepliesBar = false
                                }
                            ) {
                                Text(
                                    text = preset,
                                    color = palette.textPrimary,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Composer / Recording Bar
            if (recordingState.isRecording) {
                Surface(color = palette.surface, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = palette.error)
                        Text(
                            text = DateTimeUtils.formatDurationMillis(recordingState.elapsedMs),
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        val liveBars = if (recordingState.amplitudes.isEmpty()) {
                            List(18) { 20 }
                        } else {
                            recordingState.amplitudes.takeLast(18)
                        }
                        Row(
                            modifier = Modifier.weight(1f).height(26.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            liveBars.forEach { amp ->
                                val barHeight = (6 + (amp / 100f) * 20f).dp
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(barHeight)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(palette.turquoise)
                                )
                            }
                        }
                        TextButton(onClick = viewModel::cancelVoiceRecording) {
                            Text(strings.cancel, color = palette.error)
                        }
                        Button(
                            onClick = viewModel::stopAndSendVoiceRecording,
                            colors = ButtonDefaults.buttonColors(containerColor = palette.emerald, contentColor = palette.onPrimary)
                        ) {
                            Text(strings.send, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.surface)
                        .padding(horizontal = 6.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = {
                            if (showEmojiKeyboard) {
                                showEmojiKeyboard = false
                                composerFocusRequester.requestFocus()
                                keyboardController?.show()
                            } else {
                                keyboardController?.hide()
                                showEmojiKeyboard = true
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (showEmojiKeyboard) Icons.Default.Keyboard else Icons.Default.EmojiEmotions,
                            contentDescription = strings.switchToTextKeyboard,
                            tint = if (showEmojiKeyboard) palette.emerald else palette.textSecondary
                        )
                    }

                    IconButton(onClick = { showAttachSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.AddCircleOutline,
                            contentDescription = if (strings.isEnglish) "Attachments" else "المرفقات والموسيقى",
                            tint = palette.turquoise
                        )
                    }

                    OutlinedTextField(
                        value = inputValue,
                        onValueChange = {
                            inputValue = it
                            viewModel.onInputTextChanged(it.text)
                        },
                        placeholder = {
                            Text(if (strings.isEnglish) "Type a message..." else "اكتب رسالة...")
                        },
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(composerFocusRequester)
                            .onFocusChanged { focusState ->
                                if (focusState.isFocused && showEmojiKeyboard) {
                                    showEmojiKeyboard = false
                                }
                            },
                        minLines = 1,
                        maxLines = 6,
                        shape = RoundedCornerShape(24.dp),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (quickReplies.isNotEmpty()) {
                                    IconButton(
                                        onClick = { showQuickRepliesBar = !showQuickRepliesBar },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Bolt,
                                            contentDescription = null,
                                            tint = if (showQuickRepliesBar) palette.emerald else palette.textSecondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { showCamera = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.CameraAlt, contentDescription = strings.camera, tint = palette.textSecondary, modifier = Modifier.size(20.dp))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary,
                            cursorColor = palette.turquoise,
                            focusedBorderColor = palette.turquoise,
                            unfocusedBorderColor = palette.border,
                            focusedPlaceholderColor = palette.textMuted,
                            unfocusedPlaceholderColor = palette.textMuted,
                            focusedContainerColor = palette.surfaceElevated,
                            unfocusedContainerColor = palette.surfaceElevated
                        )
                    )

                    if (inputValue.text.isNotBlank()) {
                        FloatingActionButton(
                            onClick = {
                                viewModel.sendOrEditText(inputValue.text)
                                inputValue = TextFieldValue("")
                            },
                            modifier = Modifier.size(48.dp),
                            containerColor = palette.emerald,
                            contentColor = palette.onPrimary
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = strings.send)
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(palette.emerald)
                                .pointerInput(micPermission.status.isGranted) {
                                    detectTapGestures(
                                        onPress = {
                                            if (!micPermission.status.isGranted) {
                                                micPermission.launchPermissionRequest()
                                                return@detectTapGestures
                                            }
                                            val pressedAt = System.currentTimeMillis()
                                            viewModel.startVoiceRecording()
                                            val released = tryAwaitRelease()
                                            val heldMs = System.currentTimeMillis() - pressedAt
                                            if (released && heldMs >= 700L) {
                                                viewModel.stopAndSendVoiceRecording()
                                            }
                                        }
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = palette.onPrimary)
                        }
                    }
                }
            }

            if (showEmojiKeyboard) {
                WesalEmojiKeyboard(
                    recentEmojis = recentEmojis,
                    onEmojiSelected = { emoji ->
                        inputValue = WesalEmojiUtils.insertAtSelection(inputValue, emoji)
                        viewModel.recordRecentEmoji(emoji)
                        viewModel.onInputTextChanged(inputValue.text)
                    },
                    onBackspace = {
                        inputValue = WesalEmojiUtils.backspaceAtSelection(inputValue)
                        viewModel.onInputTextChanged(inputValue.text)
                    },
                    onSwitchToSystemKeyboard = {
                        showEmojiKeyboard = false
                        composerFocusRequester.requestFocus()
                        keyboardController?.show()
                    }
                )
            }
        }
    }

    if (showAttachSheet) {
        ModalBottomSheet(onDismissRequest = { showAttachSheet = false }, containerColor = palette.surface) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = if (strings.isEnglish) "Send Attachment & Music" else "إرسال مرفق أو ملف صوتي",
                    style = MaterialTheme.typography.titleLarge,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                val sheetItemColors = ListItemDefaults.colors(containerColor = Color.Transparent)
                ListItem(
                    headlineContent = { Text(strings.sendMusic, color = palette.textPrimary) },
                    leadingContent = { Icon(Icons.Default.MusicNote, contentDescription = null, tint = palette.emerald) },
                    colors = sheetItemColors,
                    modifier = Modifier.clickable {
                        showAttachSheet = false
                        audioPicker.launch(arrayOf("audio/*"))
                    }
                )
                ListItem(
                    headlineContent = { Text(strings.sendAudioFile, color = palette.textPrimary) },
                    leadingContent = { Icon(Icons.Default.AudioFile, contentDescription = null, tint = palette.turquoise) },
                    colors = sheetItemColors,
                    modifier = Modifier.clickable {
                        showAttachSheet = false
                        audioPicker.launch(arrayOf("audio/*", "application/ogg"))
                    }
                )
                ListItem(
                    headlineContent = { Text(strings.sendVoiceRecording, color = palette.textPrimary) },
                    leadingContent = { Icon(Icons.Default.Mic, contentDescription = null, tint = palette.emerald) },
                    colors = sheetItemColors,
                    modifier = Modifier.clickable {
                        showAttachSheet = false
                        if (micPermission.status.isGranted) {
                            viewModel.startVoiceRecording()
                        } else {
                            micPermission.launchPermissionRequest()
                        }
                    }
                )
                ListItem(
                    headlineContent = { Text(strings.sendPhoto, color = palette.textPrimary) },
                    leadingContent = { Icon(Icons.Default.Photo, contentDescription = null, tint = palette.turquoise) },
                    colors = sheetItemColors,
                    modifier = Modifier.clickable {
                        showAttachSheet = false
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                )
                ListItem(
                    headlineContent = { Text(strings.sendVideo, color = palette.textPrimary) },
                    leadingContent = { Icon(Icons.Default.Videocam, contentDescription = null, tint = palette.turquoise) },
                    colors = sheetItemColors,
                    modifier = Modifier.clickable {
                        showAttachSheet = false
                        videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    }
                )
                ListItem(
                    headlineContent = { Text(strings.chooseDeviceFile, color = palette.textPrimary) },
                    leadingContent = { Icon(Icons.Default.Description, contentDescription = null, tint = palette.emerald) },
                    colors = sheetItemColors,
                    modifier = Modifier.clickable {
                        showAttachSheet = false
                        documentPicker.launch(arrayOf("*/*"))
                    }
                )
                ListItem(
                    headlineContent = { Text(strings.sendLocation, color = palette.textPrimary) },
                    leadingContent = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = palette.warning) },
                    colors = sheetItemColors,
                    modifier = Modifier.clickable {
                        showAttachSheet = false
                        if (locationPermissions.allPermissionsGranted) {
                            val client = LocationServices.getFusedLocationProviderClient(context)
                            client.lastLocation.addOnSuccessListener { loc ->
                                if (loc != null) {
                                    viewModel.sendLocation(
                                        loc.latitude,
                                        loc.longitude,
                                        "Location (${String.format("%.4f", loc.latitude)}, ${String.format("%.4f", loc.longitude)})"
                                    )
                                }
                            }
                        } else {
                            locationPermissions.launchMultiplePermissionRequest()
                        }
                    }
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    selectedMessageForActions?.let { msg ->
        AlertDialog(
            onDismissRequest = { selectedMessageForActions = null },
            containerColor = palette.surface,
            title = { Text(if (strings.isEnglish) "Message Actions" else "خيارات الرسالة", color = palette.textPrimary) },
            text = {
                Column {
                    val actionItemColors = ListItemDefaults.colors(
                        containerColor = Color.Transparent,
                        headlineColor = palette.textPrimary,
                        leadingIconColor = palette.textSecondary
                    )
                    ListItem(
                        headlineContent = { Text(if (strings.isEnglish) "Reply" else "رد") },
                        leadingContent = { Icon(Icons.Default.Reply, contentDescription = null) },
                        colors = actionItemColors,
                        modifier = Modifier.clickable { viewModel.setReplyingTo(msg); selectedMessageForActions = null }
                    )
                    ListItem(
                        headlineContent = { Text(if (strings.isEnglish) "Forward" else "إعادة توجيه") },
                        leadingContent = { Icon(Icons.Default.Forward, contentDescription = null) },
                        colors = actionItemColors,
                        modifier = Modifier.clickable { forwardingMessage = msg; selectedMessageForActions = null }
                    )
                    if (msg.type == MessageType.AUDIO || msg.type == MessageType.VOICE) {
                        ListItem(
                            headlineContent = { Text(strings.saveAudioToDevice) },
                            leadingContent = { Icon(Icons.Default.Download, contentDescription = null, tint = palette.emerald) },
                            colors = actionItemColors,
                            modifier = Modifier.clickable {
                                viewModel.saveAudioToDownloads(msg, strings.isEnglish)
                                selectedMessageForActions = null
                            }
                        )
                    }
                    if (msg.text.isNotBlank()) {
                        ListItem(
                            headlineContent = { Text(strings.copy) },
                            leadingContent = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                            colors = actionItemColors,
                            modifier = Modifier.clickable {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("wesal_msg", msg.text))
                                selectedMessageForActions = null
                            }
                        )
                    }
                    if (msg.senderId == viewModel.myUid && msg.type == MessageType.TEXT && !msg.isDeletedForEveryone) {
                        ListItem(
                            headlineContent = { Text(strings.edit) },
                            leadingContent = { Icon(Icons.Default.Edit, contentDescription = null) },
                            colors = actionItemColors,
                            modifier = Modifier.clickable { viewModel.setEditingMessage(msg); selectedMessageForActions = null }
                        )
                    }
                    ListItem(
                        headlineContent = { Text(if (strings.isEnglish) "Delete for me" else "حذف لدي") },
                        leadingContent = { Icon(Icons.Default.DeleteOutline, contentDescription = null) },
                        colors = actionItemColors,
                        modifier = Modifier.clickable { viewModel.deleteForMe(msg.messageId); selectedMessageForActions = null }
                    )
                    if (msg.senderId == viewModel.myUid && !msg.isDeletedForEveryone) {
                        ListItem(
                            headlineContent = { Text(if (strings.isEnglish) "Delete for everyone" else "حذف لدى الجميع", color = palette.error) },
                            leadingContent = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = palette.error) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { viewModel.deleteForEveryone(msg.messageId); selectedMessageForActions = null }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedMessageForActions = null }) { Text(strings.close) }
            }
        )
    }

    forwardingMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { forwardingMessage = null },
            containerColor = palette.surface,
            title = { Text(if (strings.isEnglish) "Forward to" else "إعادة توجيه إلى", color = palette.textPrimary) },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                    items(allChats, key = { it.chatId }) { target ->
                        ListItem(
                            headlineContent = { Text(target.title, color = palette.textPrimary) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable {
                                viewModel.forwardMessage(target.chatId, msg)
                                forwardingMessage = null
                            }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { forwardingMessage = null }) { Text(strings.cancel) }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    message: WesalMessage,
    isMine: Boolean,
    isGroup: Boolean,
    decryptedFile: File?,
    playbackState: VoicePlaybackState,
    onRequestMedia: () -> Unit,
    onOpenImage: () -> Unit,
    onPlayVideo: () -> Unit,
    onToggleVoice: () -> Unit,
    onSeekAudio: (Int) -> Unit,
    onSetVolume: (Float) -> Unit,
    onSaveAudio: () -> Unit,
    onOpenDocument: () -> Unit,
    onOpenLocation: () -> Unit,
    onLongClick: () -> Unit
) {
    val palette = WesalColors.current
    val strings = LocalWesalStrings.current

    val isThisAudioActive = playbackState.activeMessageId == message.messageId
    val isVoicePlaying = isThisAudioActive && playbackState.isPlaying
    val voiceProgress = if (isThisAudioActive && playbackState.durationMs > 0) {
        playbackState.positionMs.toFloat() / playbackState.durationMs.toFloat()
    } else {
        0f
    }

    LaunchedEffect(message.messageId, message.type) {
        if ((message.type == MessageType.IMAGE) && decryptedFile == null && message.mediaUrl.isNotBlank()) {
            onRequestMedia()
        }
    }

    val alignment = if (isMine) Alignment.CenterEnd else Alignment.CenterStart
    val bubbleColor = if (isMine) palette.bubbleOutgoing else palette.bubbleIncoming

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = alignment) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMine) 16.dp else 4.dp,
                bottomEnd = if (isMine) 4.dp else 16.dp
            ),
            modifier = Modifier
                .widthIn(max = 310.dp)
                .combinedClickable(onClick = {}, onLongClick = onLongClick)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (!isMine && isGroup && message.senderName.isNotBlank()) {
                    Text(message.senderName, style = MaterialTheme.typography.labelMedium, color = palette.turquoise)
                }

                if (!message.forwardedFromName.isNullOrBlank()) {
                    Text(
                        text = if (strings.isEnglish) "Forwarded from ${message.forwardedFromName}" else "محولة من ${message.forwardedFromName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary
                    )
                }

                if (!message.replyToPreview.isNullOrBlank()) {
                    Surface(color = palette.surface.copy(alpha = 0.65f), shape = RoundedCornerShape(8.dp)) {
                        Text(
                            text = message.replyToPreview,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textSecondary,
                            maxLines = 2,
                            modifier = Modifier.padding(6.dp)
                        )
                    }
                }

                when (message.type) {
                    MessageType.IMAGE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.surface)
                                .clickable { onOpenImage() },
                            contentAlignment = Alignment.Center
                        ) {
                            if (decryptedFile != null) {
                                AsyncImage(
                                    model = decryptedFile,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                CircularProgressIndicator(color = palette.turquoise, modifier = Modifier.size(26.dp))
                            }
                        }
                        if (message.text.isNotBlank()) {
                            Text(message.text, style = MaterialTheme.typography.bodyLarge, color = palette.textPrimary)
                        }
                    }

                    MessageType.VIDEO -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.surface)
                                .clickable { onPlayVideo() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = palette.turquoise, modifier = Modifier.size(52.dp))
                        }
                        if (message.text.isNotBlank()) {
                            Text(message.text, style = MaterialTheme.typography.bodyLarge, color = palette.textPrimary)
                        }
                    }

                    MessageType.AUDIO -> {
                        val totalMs = if (isThisAudioActive && playbackState.durationMs > 1) {
                            playbackState.durationMs.toLong()
                        } else {
                            message.mediaDurationMs.coerceAtLeast(0L)
                        }
                        val posMs = if (isThisAudioActive) playbackState.positionMs.toLong() else 0L
                        val sizeKb = (message.mediaSizeBytes / 1024L).coerceAtLeast(1L)

                        Surface(
                            color = palette.surface.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, palette.border),
                            modifier = Modifier.width(265.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = palette.emerald.copy(alpha = 0.16f),
                                        shape = CircleShape,
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            IconButton(onClick = onToggleVoice, modifier = Modifier.size(38.dp)) {
                                                Icon(
                                                    imageVector = if (isVoicePlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    tint = palette.emerald
                                                )
                                            }
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = message.mediaFileName.ifBlank { if (strings.isEnglish) "Audio Track" else "ملف صوتي" },
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = palette.textPrimary,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${DateTimeUtils.formatDurationMillis(posMs)} / ${DateTimeUtils.formatDurationMillis(totalMs)} • ${sizeKb} KB",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.textSecondary
                                        )
                                    }
                                    IconButton(onClick = onSaveAudio, modifier = Modifier.size(32.dp)) {
                                        Icon(
                                            Icons.Default.Download,
                                            contentDescription = strings.saveAudioToDevice,
                                            tint = palette.turquoise,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                val seekDuration = totalMs.coerceAtLeast(1L).toFloat()
                                Slider(
                                    value = if (isThisAudioActive) posMs.toFloat().coerceIn(0f, seekDuration) else 0f,
                                    onValueChange = { newPos ->
                                        if (isThisAudioActive) onSeekAudio(newPos.toInt())
                                    },
                                    valueRange = 0f..seekDuration,
                                    colors = SliderDefaults.colors(
                                        thumbColor = palette.turquoise,
                                        activeTrackColor = palette.turquoise,
                                        inactiveTrackColor = palette.border
                                    ),
                                    modifier = Modifier.fillMaxWidth().height(24.dp)
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    IconButton(
                                        onClick = { onSetVolume(if (playbackState.volume > 0f) 0f else 1f) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (playbackState.volume <= 0.01f) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                            contentDescription = null,
                                            tint = palette.textSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Slider(
                                        value = playbackState.volume,
                                        onValueChange = onSetVolume,
                                        valueRange = 0f..1f,
                                        colors = SliderDefaults.colors(
                                            thumbColor = palette.emerald,
                                            activeTrackColor = palette.emerald,
                                            inactiveTrackColor = palette.border
                                        ),
                                        modifier = Modifier.weight(1f).height(20.dp)
                                    )
                                }
                            }
                        }
                    }

                    MessageType.VOICE -> {
                        val bars = if (message.waveformAmplitudes.isNotEmpty()) {
                            message.waveformAmplitudes.take(28)
                        } else {
                            listOf(18, 36, 54, 42, 70, 88, 60, 44, 72, 92, 50, 32, 66, 80, 48, 30, 58, 74, 40, 26)
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.width(245.dp)
                        ) {
                            IconButton(onClick = onToggleVoice, modifier = Modifier.size(38.dp)) {
                                Icon(
                                    imageVector = if (isVoicePlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                    contentDescription = null,
                                    tint = palette.turquoise,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().height(26.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    bars.forEachIndexed { idx, amp ->
                                        val frac = (idx + 1).toFloat() / bars.size.toFloat()
                                        val isPlayed = voiceProgress > 0f && frac <= voiceProgress
                                        val barHeight = (5 + (amp.coerceIn(10, 100) / 100f) * 20f).dp
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(barHeight)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(if (isPlayed) palette.turquoise else palette.border)
                                        )
                                    }
                                }
                                Text(
                                    text = DateTimeUtils.formatDurationMillis(
                                        if (isThisAudioActive && playbackState.isPlaying) playbackState.positionMs.toLong()
                                        else message.mediaDurationMs
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.textSecondary
                                )
                            }
                            IconButton(onClick = onSaveAudio, modifier = Modifier.size(28.dp)) {
                                Icon(
                                    Icons.Default.Download,
                                    contentDescription = strings.saveAudioToDevice,
                                    tint = palette.emerald,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    MessageType.DOCUMENT -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.surface.copy(alpha = 0.65f))
                                .clickable { onOpenDocument() }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = palette.turquoise)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(message.mediaFileName.ifBlank { "Document" }, color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${(message.mediaSizeBytes / 1024L).coerceAtLeast(1)} KB", style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                            }
                            Icon(Icons.Default.Download, contentDescription = null, tint = palette.emerald)
                        }
                    }

                    MessageType.LOCATION -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.surface.copy(alpha = 0.65f))
                                .clickable { onOpenLocation() }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = palette.emerald)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(if (strings.isEnglish) "Location" else "موقع جغرافي", color = palette.textPrimary, fontWeight = FontWeight.Bold)
                                Text(message.locationAddress, style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                            }
                        }
                    }

                    else -> {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (message.isDeletedForEveryone) palette.textMuted else palette.textPrimary
                        )
                    }
                }

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (message.isEdited) {
                        Text(
                            text = if (strings.isEnglish) "edited" else "معدلة",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textMuted
                        )
                    }
                    Text(
                        text = DateTimeUtils.formatMessageTime(message.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary
                    )
                    if (isMine) {
                        MessageStatusTick(status = message.status)
                    }
                }
            }
        }
    }
}
